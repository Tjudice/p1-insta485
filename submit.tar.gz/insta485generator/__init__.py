"""A static site generator."""
